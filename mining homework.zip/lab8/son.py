import copy
import itertools


def getSupport(sets, item):
    support = 0
    for s in sets:
        flag = True
        for i in item:
            if i not in s:
                flag = False
                break
        if flag:
            support += 1
    return support


def generateCandidate(material, items):
    if not material or len(material[0]) >= len(items):
        return None

    candidates = []
    for i in range(len(items)):
        for j in range(len(material)):
            if items[i] not in material[j]:
                tmp = copy.deepcopy(material[j])
                tmp.append(items[i])
                tmp.sort()
                candidates.append(tmp)

    distinct = []
    for i in candidates:
        if i not in distinct:
            distinct.append(i)

    return distinct


def son(sets, th_support):
    result = []
    candidate = []
    for s in sets:
        candidate.extend(s)

    # setup
    items = [i for i in list(set(candidate))]
    candidate = [[i] for i in items]

    while candidate:
        # material: result for this time
        material = []
        for ca in candidate:
            support = getSupport(sets, ca)
            if support >= th_support:
                material.append(ca)

        result.extend(material)
        candidate = generateCandidate(material, items)

    return result

def getConfidence(item1,item2,sets):
    item1=list(item1)
    item1.extend(item2)
    s1=getSupport(sets,item1)
    s2=getSupport(sets,item2)
    if not s2:
        return 0

    return s1/s2

def getRule(th_confidence,frequent_items,sets):
    conditions=[]
    buckets=[]
    for item in frequent_items:
        # print(item)
        if len(item)<=1:
            continue
        condition_list=[]
        buckets_list=[]
        for i in range(1,len(item)):
            condition_list.extend(list(itertools.combinations(item,i)))
        # for i in range(len(condition_list)):
        #     condition_list[i]=list(condition_list[i])
        for i in range(len(condition_list)):
            condition=condition_list[i]
            bucket=[]
            for j in item:
                if j not in condition:
                    bucket.append(j)
            buckets_list.append(bucket)
        # print(condition_list)
        # print(buckets_list)

        for i in range(len(condition_list)):
            condition=condition_list[i]
            bucket=buckets_list[i]
            confidence=getConfidence(condition,bucket,sets)
            if confidence>=th_confidence:
                conditions.append(condition)
                buckets.append(bucket)

    return conditions,buckets

def getInterest(item1,item2,sets):
    c=getConfidence(item1,item2,sets)
    # print(list(item2))
    s=getSupport(sets,item2)
    if not s:
        return None,None
    return c,abs(s-c)




if __name__ == "__main__":
    signals = [[1, 2, 3, 4, 5], [1, 2, 3], [1, 2,3], [5]]

    frequent_items = son(signals, 1)
    conditions,buckets=getRule(0.9,frequent_items,signals)

    for i in range(len(conditions)):
        print(conditions[i],'->',buckets[i],'are associate rules')
        cf,it=getInterest(conditions[i],buckets[i],signals)
        print('confidence:',cf,',interestness:',it)


