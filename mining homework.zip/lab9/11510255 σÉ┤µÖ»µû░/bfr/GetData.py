import os
from getBfr import getBfrCluster
import numpy as np

# read stocks with director array
def get_fileList(dirs):
    for d in dirs:
        fileList = []
        files = os.listdir(d)
        for f in files:
            path = d + '/' + f
            if (os.path.isfile(path)):
                fileList.append(path)

    return fileList


# read stocks information in a file
def readfile(file):
    stock = []
    with open(file) as f:
        lines = f.readlines()

    for line in lines:
        ls = line[:-1].split(',')[2:5]
        ls = [float(l) for l in ls]
        stock.append(ls)

    return stock

if __name__=='__main__':
    filelist=get_fileList(['Stk_1F_2016'])
    stocks=[]
    for file in filelist:
        stock=readfile(file)
        stocks.append(stock[0])
    getBfrCluster(np.array(stocks), K=3,dimension=3)