# lab9

## 吴景新 11510255



* For each asset, we extract the Opening price, highest price, lowest price, closing price (yuan), transaction amount (million), volume of the stocks.
* The **discard set** contains the main clusters.
* The **compress set** contains points that are far from clusters in discard but close to eachother. These get summarized as clusters.
* The **retain set** contains points that are far from clusters in both discard and compress and also far from other points in retain.

![image-20190517000821086](/Users/do/Library/Application Support/typora-user-images/image-20190517000821086.png)

## Visualization

![image-20190517000618377](/Users/do/Library/Application Support/typora-user-images/image-20190517000618377.png)

* Three cluster
* Three centers
* Three dimensions,  opening price, highest price, lowest price

Reference:

python Brf library

https://github.com/jeppeb91/bfr> 