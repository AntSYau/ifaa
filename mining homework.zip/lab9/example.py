import bfr
from sklearn.datasets.samples_generator import make_blobs

# Generate test data
vectors, _ = make_blobs(n_samples=1000, cluster_std=1,
                        n_features=2, centers=5,
                        shuffle=True)

# Create the model. See below for parameter description
model = bfr.Model(mahalanobis_factor=3.0, euclidean_threshold=3.0,
                  merge_threshold=2.0, dimensions=2,
                  init_rounds=40, nof_clusters=5)

# Fit the model using 500 vectors
model.fit(vectors[:500])

# Fit (Update) the model using 500 other vectors
model.fit(vectors[500:])

# Finalize assigns clusters in the compress and retain set to the closest cluster in discard
model.finalize()

# Print the residual sum of square error
print(model.error(vectors))

# Print cheap standard deviation based error without going through every vector
print(model.error())

# Predict the which cluster some points belong to
predictions = model.predict(vectors[:2])

# Predict the which cluster some points belong to
# Outlier_detection=True defines that points far from their closest cluster will be identified
predictions = model.predict(vectors[:2], outlier_detection=True)

# Get the centers of the model as a numpy array
centers = model.centers()

# Print the model
print(model)

# Plot the model
model.plot()

# Plot the model and add points to the plot
model.plot(vectors, outlier_detection=False)