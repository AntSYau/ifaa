# LAB4

## How codes work

### Functions

* Set up the environment:  

  * the interval
  * the moving average output file path

* The pattern is to analyse the pattern about the day that rising rate higher than 0.5% the next day

* Identify the pairs

  ![image-20190329224042614](/Users/do/Library/Application Support/typora-user-images/image-20190329224042614.png)

* Caculate the J Similarity using numpy

  ![image-20190329224024542](/Users/do/Library/Application Support/typora-user-images/image-20190329224024542.png)





