import math

filename = "test.txt"

container = {}
windowsize = 100
timestamp = 0
updateinterval = 50# no larger than the windowsize
updateindex = 0

keysnum = int(math.log(windowsize, 2)) + 1
keylist = list()
# initialize the container
for i in range(keysnum):
    key = int(math.pow(2, i))
    keylist.append(key)
    container[key] = list()

def UpdateContainer(inputdict, klist, numkeys):
    for key in klist:
        if len(inputdict[key]) > 2:
            inputdict[key].pop(0)
            tstamp = inputdict[key].pop(0)
            if key != klist[-1]:
                inputdict[key * 2].append(tstamp)
        else:
            break

def OutputResult(inputdict, klist, wsize):
    cnt = 0
    firststamp = 0
    for key in klist:
        if len(inputdict[key]) > 0:
            firststamp = inputdict[key][0]
        for tstamp in inputdict[key]:
            print("size of bucket: %d, timestamp: %d" % (key, tstamp))
    for key in klist:
        for tstamp in inputdict[key]:
            if tstamp != firststamp:
                cnt += key
            else:
                cnt += 0.5 * key
    print("Estimated number of ones in the last %d bits: %d" % (wsize, cnt))



import json
import numpy as np
import os


# read stocks with director array
def get_fileList(dirs):
    for d in dirs:
        fileList = []
        files = os.listdir(d)
        for f in files:
            path = d + '/' + f
            if (os.path.isfile(path)):
                fileList.append(path)

    return fileList


# read stocks information in a file
def readfile(file):
    stock = []
    with open(file) as f:
        lines = f.readlines()

    for line in lines:
        ls = line[:-1].split(',')
        stock.append(ls)

    return stock


def get_closing_prices(stock):
    days = []
    closing_prices = []
    for line in stock:
        if line[1] == '15:00':
            days.append(line[0])
            closing_prices.append(float(line[-3]))
    return days, closing_prices


def get_avgs(stock, interval, save, filename):
    days, closing_prices = get_closing_prices(stock)

    length = len(closing_prices)
    if length <= interval:
        return [], []

    avgs = [sum(closing_prices[i - interval:i]) / interval for i in range(interval, length)]
    days = days[interval:]

    if save:
        with open('{}_ma.out'.format(filename), 'w') as f:
            f.write(json.dumps(days))
            f.write('\n')
            f.write(json.dumps(avgs))

    return days, avgs


# The stocks should same date order
def readMA(path):
    with open(path) as f:
        dates = json.loads(f.readline())
        mas = json.loads(f.readline())
    return dates, mas


# get the day that rising rate higher than 0.5% the next day
def getRise(ma):
    result = []
    for i in range(len(ma) - 1):
        if ma[i + 1] - ma[i] > 0.005 * ma[i]:
            result.append(1)
        else:
            result.append(0)
    return result


def getJSimilar(ma1, ma2, origin1, origin2):
    cross = [ma1[i] and ma2[i] for i in range(len(ma1))]
    x = np.array(cross)
    idxs = np.where(x == 1)[0]
    pairs = [(origin1[i], origin2[i]) for i in idxs]

    return sum(cross) / len(ma1), pairs


if __name__ == '__main__':
    interval = 10
    stock_path = 'Stk_1F_2016/SH000001.csv'
    save_filename = stock_path.split('/')[-1][:-4]
    save = True

    stock = readfile(stock_path)
    days, avgs = get_avgs(stock, interval, save, save_filename)

    stock_path = 'Stk_1F_2016/SH000002.csv'
    save_filename = stock_path.split('/')[-1][:-4]

    stock = readfile(stock_path)
    days, avgs = get_avgs(stock, interval, save, save_filename)

    date1, ma1 = readMA('SH000001_ma.out')
    date2, ma2 = readMA('SH000002_ma.out')

    # print(ma1)

    for v in ma1:
        # char = sfile.read(1)
        # if not char:  # no more input
        #     OutputResult(container, keylist, windowsize)
        #     break
        timestamp = (timestamp + 1) % windowsize
        for k in container.keys():
            for itemstamp in container[k]:
                if itemstamp == timestamp:  # remove record which is out of the window
                    container[k].remove(itemstamp)
        if v >= 3000:  # add it to the container
            container[1].append(timestamp)
            UpdateContainer(container, keylist, keysnum)
        updateindex = (updateindex + 1) % updateinterval
        # if updateindex == 0:
        #     OutputResult(container, keylist, windowsize)
        #     print("\n")

    OutputResult(container, keylist, windowsize)







