import random

def trailing_zeroes(num):
  if num == 0:
    return 32 # Assumes 32 bit integer inputs!
  p = 0
  while (num >> p) & 1 == 0:
    p += 1
  return p

def estimate(values,k):
  num_buckets = 2 ** k
  max_zeroes = [0] * num_buckets
  for value in values:
    h = hash(value)
    bucket = h & (num_buckets - 1) # Mask out the k least significant bits as bucket ID
    bucket_hash = h >> k
    max_zeroes[bucket] = max(max_zeroes[bucket],trailing_zeroes(bucket_hash))
  return 2 ** (float(sum(max_zeroes)) / num_buckets) * num_buckets * 0.79402

# emp=[estimate_cardinality([random.random() for i in range(100000)],10) for j in range(10)]
# emp.sort()
# print(round(emp[5]))

import json
import numpy as np
import os


# read stocks with director array
def get_fileList(dirs):
    for d in dirs:
        fileList = []
        files = os.listdir(d)
        for f in files:
            path = d + '/' + f
            if (os.path.isfile(path)):
                fileList.append(path)

    return fileList


# read stocks information in a file
def readfile(file):
    stock = []
    with open(file) as f:
        lines = f.readlines()

    for line in lines:
        ls = line[:-1].split(',')
        stock.append(ls)

    return stock


def get_closing_prices(stock):
    days = []
    closing_prices = []
    for line in stock:
        if line[1] == '15:00':
            days.append(line[0])
            closing_prices.append(float(line[-3]))
    return days, closing_prices


def get_avgs(stock, interval, save, filename):
    days, closing_prices = get_closing_prices(stock)

    length = len(closing_prices)
    if length <= interval:
        return [], []

    avgs = [sum(closing_prices[i - interval:i]) / interval for i in range(interval, length)]
    days = days[interval:]

    if save:
        with open('{}_ma.out'.format(filename), 'w') as f:
            f.write(json.dumps(days))
            f.write('\n')
            f.write(json.dumps(avgs))

    return days, avgs


# The stocks should same date order
def readMA(path):
    with open(path) as f:
        dates = json.loads(f.readline())
        mas = json.loads(f.readline())
    return dates, mas


# get the day that rising rate higher than 0.5% the next day
def getRise(ma):
    result = []
    for i in range(len(ma) - 1):
        if ma[i + 1] - ma[i] > 0.005 * ma[i]:
            result.append(1)
        else:
            result.append(0)
    return result


def getJSimilar(ma1, ma2, origin1, origin2):
    cross = [ma1[i] and ma2[i] for i in range(len(ma1))]
    x = np.array(cross)
    idxs = np.where(x == 1)[0]
    pairs = [(origin1[i], origin2[i]) for i in idxs]

    return sum(cross) / len(ma1), pairs


if __name__ == '__main__':
    interval = 10
    stock_path = 'Stk_1F_2016/SH000001.csv'
    save_filename = stock_path.split('/')[-1][:-4]
    save = True

    stock = readfile(stock_path)
    days, avgs = get_avgs(stock, interval, save, save_filename)

    stock_path = 'Stk_1F_2016/SH000002.csv'
    save_filename = stock_path.split('/')[-1][:-4]

    stock = readfile(stock_path)
    days, avgs = get_avgs(stock, interval, save, save_filename)

    date1, ma1 = readMA('SH000001_ma.out')
    date2, ma2 = readMA('SH000002_ma.out')

    # print(ma1)

    emp = [estimate(ma1, 10) for j in range(10)]
    emp.sort()
    print('distinct items number:{}'.format(round(emp[5])))








