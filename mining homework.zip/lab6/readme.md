# LAB6

## Problem 1

* Use DGIM to estimate the moving average > 3000  in the last 100 days.

![image-20190419202254847](/Users/do/Library/Application Support/typora-user-images/image-20190419202254847.png)

## Problem 2

* Use FM to find distinct signals numbers.

![image-20190419202320014](/Users/do/Library/Application Support/typora-user-images/image-20190419202320014.png)



## Problem 3

* Choose 11 signals about moving average and use bloom filters to find whether it is preserved in 30 days.

![image-20190419202346152](/Users/do/Library/Application Support/typora-user-images/image-20190419202346152.png)