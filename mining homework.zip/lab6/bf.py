from pybloom import BloomFilter

def isPreserved(a,name):
    f = BloomFilter(capacity=30, error_rate=0.001)
    for i in range(30):
        f.add(a[i])

    return '{} is preserved in 30 days'.format(name) if f.add(a[31]) else '{} is not preserved in 30 days'.format(name)


import json
import numpy as np
import os


# read stocks with director array
def get_fileList(dirs):
    for d in dirs:
        fileList = []
        files = os.listdir(d)
        for f in files:
            path = d + '/' + f
            if (os.path.isfile(path)):
                fileList.append(path)

    return fileList


# read stocks information in a file
def readfile(file):
    stock = []
    with open(file) as f:
        lines = f.readlines()

    for line in lines:
        ls = line[:-1].split(',')
        stock.append(ls)

    return stock


def get_closing_prices(stock):
    days = []
    closing_prices = []
    for line in stock:
        if line[1] == '15:00':
            days.append(line[0])
            closing_prices.append(float(line[-3]))
    return days, closing_prices


def get_avgs(stock, interval, save, filename):
    days, closing_prices = get_closing_prices(stock)

    length = len(closing_prices)
    if length <= interval:
        return [], []

    avgs = [sum(closing_prices[i - interval:i]) / interval for i in range(interval, length)]
    days = days[interval:]

    if save:
        with open('{}_ma.out'.format(filename), 'w') as f:
            f.write(json.dumps(days))
            f.write('\n')
            f.write(json.dumps(avgs))

    return days, avgs


# The stocks should same date order
def readMA(path):
    with open(path) as f:
        dates = json.loads(f.readline())
        mas = json.loads(f.readline())
    return dates, mas


# get the day that rising rate higher than 0.5% the next day
def getRise(ma):
    result = []
    for i in range(len(ma) - 1):
        if ma[i + 1] - ma[i] > 0.005 * ma[i]:
            result.append(1)
        else:
            result.append(0)
    return result


def getJSimilar(ma1, ma2, origin1, origin2):
    cross = [ma1[i] and ma2[i] for i in range(len(ma1))]
    x = np.array(cross)
    idxs = np.where(x == 1)[0]
    pairs = [(origin1[i], origin2[i]) for i in idxs]

    return sum(cross) / len(ma1), pairs


if __name__ == '__main__':
    interval = 10
    stock_path = 'Stk_1F_2016/SH000001.csv'
    save_filename = stock_path.split('/')[-1][:-4]
    save = True

    stock = readfile(stock_path)
    days, avgs = get_avgs(stock, interval, save, save_filename)

    stock_path = 'Stk_1F_2016/SH000002.csv'
    save_filename = stock_path.split('/')[-1][:-4]

    stock = readfile(stock_path)
    days, avgs = get_avgs(stock, interval, save, save_filename)

    date1, ma1 = readMA('SH000001_ma.out')
    date2, ma2 = readMA('SH000002_ma.out')

    s1 = [1 if i > 5000 else 0 for i in ma1]
    s2 = [1 if i > 4500 else 0 for i in ma1]
    s3 = [1 if i > 4000 else 0 for i in ma1]
    s4 = [1 if i > 3500 else 0 for i in ma1]
    s5 = [1 if i > 3000 else 0 for i in ma1]
    s6 = [1 if i > 2500 else 0 for i in ma1]
    s7 = [1 if i > 2000 else 0 for i in ma1]
    s8 = [1 if i > 1500 else 0 for i in ma1]
    s9 = [1 if i > 1000 else 0 for i in ma1]
    s10 = [1 if i > 500 else 0 for i in ma1]
    s11 = [1 if i > 100 else 0 for i in ma1]

    print(isPreserved(s1,'signal1'))
    print(isPreserved(s2, 'signal2'))
    print(isPreserved(s3, 'signal3'))
    print(isPreserved(s4, 'signal4'))
    print(isPreserved(s5, 'signal5'))
    print(isPreserved(s6, 'signal6'))
    print(isPreserved(s7, 'signal7'))
    print(isPreserved(s8, 'signal8'))
    print(isPreserved(s9, 'signal9'))
    print(isPreserved(s10, 'signal10'))
    print(isPreserved(s11, 'signal11'))








