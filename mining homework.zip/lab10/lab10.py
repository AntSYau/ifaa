import requests
from bs4 import BeautifulSoup
import traceback
import re
import json


def getHTMLText(url):
    try:
        r = requests.get(url)
        r.raise_for_status()
        r.encoding = r.apparent_encoding
        return r.text
    except:
        return ""


def getStockList(lst, stockURL):
    html = getHTMLText(stockURL)
    soup = BeautifulSoup(html, 'html.parser')
    a = soup.find_all('a')
    for i in a:
        try:
            href = i.attrs['href']
            lst.append(re.findall(r"[s][hz]\d{6}", href)[0])
        except:
            continue


def getStockInfo(lst, stockURL, fpath):
    rs=[]
    count = 0
    for stock in lst:
        url = stockURL + stock + ".html"
        html = getHTMLText(url)
        try:
            if html == "":
                continue
            infoDict = {}
            soup = BeautifulSoup(html, 'html.parser')
            stockInfo = soup.find('div', attrs={'class': 'stock-bets'})

            name = stockInfo.find_all(attrs={'class': 'bets-name'})[0]
            infoDict.update({'股票名称': name.text.split()[0]})

            keyList = stockInfo.find_all('dt')
            valueList = stockInfo.find_all('dd')
            for i in range(len(keyList)):
                key = keyList[i].text
                val = valueList[i].text
                infoDict[key] = val

            with open(fpath, 'a', encoding='utf-8') as f:
                # f.write(str(infoDict) + '\n')
                rs.append(infoDict)
                count = count + 1
                print("\r当前进度: {:.2f}%".format(count * 100 / len(lst)), end="")
        except:
            count = count + 1
            print("\r当前进度: {:.2f}%".format(count * 100 / len(lst)), end="")
            continue

    return rs


def getSimilar(rs):
    min_i=0
    min_j=1
    min_v=1000
    l=len(rs)
    for i in range(l):
        for j in range(i+1,l):
            v=abs(float(rs[i]['涨停'])-float(rs[j]['涨停']))
            if v<min_v:
                min_v=v
                min_i=i
                min_j=j
    return min_i,min_j

def main():
    stock_list_url = 'http://quote.eastmoney.com/stocklist.html'
    stock_info_url = 'https://gupiao.baidu.com/stock/'
    output_file = './StockInfo.txt'
    slist = []
    getStockList(slist, stock_list_url)

    slist.append('sz300498')
    slist.append('sh600809')
    rs=getStockInfo(slist, stock_info_url, output_file)

    # print(rs[0])
    a,b=getSimilar(rs)

    print("similar news are")
    print(slist[a])
    print(slist[b])


main()