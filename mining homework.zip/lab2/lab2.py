from multiprocessing import Pool
import json
import os

#read stocks with director array
def get_fileList(dirs):
    for d in dirs:
        fileList = []
        files = os.listdir(d)
        for f in files:  
            path=d+'/'+f
            if(os.path.isfile(path)):
                fileList.append(path)
    
    return fileList

#read stocks information in a file
def readfile(file):
    stock=[]
    with open(file) as f:
        lines=f.readlines()
        
    for line in lines:
        ls=line[:-1].split(',')
        stock.append(ls)
    
    return stock



def write_output(outputs):
    with open('close>open.out','w') as f:
        for i in outputs:
            f.write(str(i)+'\n')
        
def combine_output(o1,o2):
    o1.extend(o2)
    return o1

def count_days(filename):
    stock = readfile(filename)
    
    count=0
    
    days=set()
    for line in stock:
        days.add(line[0])
    days=list(days)
    
    for day in days:
        count+=isHigher(stock,day)
    
    return (filename.split('/')[-1][:-4],count)
            
def isHigher(stock,day):
    start,end=0.0,0.0
    for line in stock:
        if line[0]==day:
            if line[1]=='09:31':
                start=float(line[2])
            elif line[1]=='15:00':
                end = float(line[5])
                break
    if end>start:
        return 1
    else:
        return 0

def myreduce(func, *args):
    if not args or not func:
        raise Exception('Illegal input')

    result=args[0]
    for i in range(1,len(args)):
        result=func(result,args[i])
    

    return result


def mymap(func, *args):
    if not args or not func:
        raise Exception('Illegal input')

    a=args[0]
    
    result=[]

    for i in a:
        result.append(func(i))
        
    return result



def control(fileList,processes):
    p=Pool(processes)
    outputs=[]
    
    for filename in fileList:
        one=p.apply_async(mymap,args=(count_days,[filename],)).get()
        outputs=p.apply_async(myreduce,args=(combine_output,outputs,one)).get()
        
    p.close()
    p.join()
    
    
    
    print(outputs)
    write_output(outputs)
    
if __name__=='__main__':

    processes=6

    directorys=['Stk_1F_2016']

    fileList=get_fileList(directorys)

    # fileList=['Stk_1F_2015/SH000001.csv','Stk_1F_2015/SH000002.csv']

    control(fileList,processes)
    


    