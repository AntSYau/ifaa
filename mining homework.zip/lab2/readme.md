# LAB2

## How codes work

### Data Structure

* Each result will be store in a tuple and print to a file named 'close>open.out' later.

  ![image-20190315153652453](/Users/do/Library/Application Support/typora-user-images/image-20190315153652453.png)

### Functions

* Set up the environment:  

  * the process number of the program
  * the array of path of dataset directorys

  ![image-20190315154727626](/Users/do/Library/Application Support/typora-user-images/image-20190315154727626.png)

* the control function will deliver tasks to map and reduce function in parallel paths

  ![image-20190315155113424](/Users/do/Library/Application Support/typora-user-images/image-20190315155113424.png)

* mymap will deal with a file each time and count the number of days the stock qualified

  ![image-20190315155507258](/Users/do/Library/Application Support/typora-user-images/image-20190315155507258.png)

  ![image-20190315155545584](/Users/do/Library/Application Support/typora-user-images/image-20190315155545584.png)

* myreduce will combine outputs into one array

  ![image-20190315155608489](/Users/do/Library/Application Support/typora-user-images/image-20190315155608489.png)

  ![image-20190315155619047](/Users/do/Library/Application Support/typora-user-images/image-20190315155619047.png)

  

  ## PS.

  * mapreduce can also be implemented in reading lines of a single file but it work not quiet well when we conduct multiprocessing and each file is of small size. So I do not adopt this method considering the performance.

