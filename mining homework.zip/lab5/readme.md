# LAB5

## How codes work

### Functions

* The pattern is to analyse the pattern about the day that rising rate higher than 0.5% the next day

* I use a python package called datasketch which gives probabilistic data structures that can process and search very large amount of data super fast, with little loss of accuracy.

  ![image-20190412232226991](/Users/do/Library/Application Support/typora-user-images/image-20190412232226991.png)

* match the most similar stock's index in the corrsponding array

* return the index and the estimated Jaccard  calculated by Minhash

  ![image-20190412232211342](/Users/do/Library/Application Support/typora-user-images/image-20190412232211342.png)

  ![image-20190412232010055](/Users/do/Library/Application Support/typora-user-images/image-20190412232010055.png)
