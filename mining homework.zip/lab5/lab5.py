import json
import numpy as np
import os

#read stocks with director array
def get_fileList(dirs):
    for d in dirs:
        fileList = []
        files = os.listdir(d)
        for f in files:  
            path=d+'/'+f
            if(os.path.isfile(path)):
                fileList.append(path)
    
    return fileList

#read stocks information in a file
def readfile(file):
    stock=[]
    with open(file) as f:
        lines=f.readlines()
        
    for line in lines:
        ls=line[:-1].split(',')
        stock.append(ls)
    
    return stock

def get_closing_prices(stock):
    days=[]
    closing_prices=[]
    for line in stock:
        if line[1]=='15:00':
            days.append(line[0])
            closing_prices.append(float(line[-3]))
    return days,closing_prices
    

def get_avgs(stock,interval,save,filename):
    days,closing_prices=get_closing_prices(stock)

    length=len(closing_prices)
    if length<=interval:
        return [],[]
    
    avgs=[ sum(closing_prices[i-interval:i])/interval for i in range(interval,length)]
    days=days[interval:]
    
    if save:
        with open('{}_ma.out'.format(filename),'w') as f:
            f.write(json.dumps(days))
            f.write('\n')
            f.write(json.dumps(avgs))
    
    return days,avgs

# The stocks should same date order
def readMA(path):
    with open(path) as f:
        dates = json.loads(f.readline())
        mas = json.loads(f.readline())
    return dates,mas

# get the day that rising rate higher than 0.5% the next day 
def getRise(ma):
    result=[]
    for i in range(len(ma)-1):
        if ma[i+1]-ma[i]>0.005*ma[i]:
            result.append(1)
        else:
            result.append(0)
    return result

def getJSimilar(ma1,ma2,origin1,origin2):
    cross=[ma1[i] and ma2[i] for i in range(len(ma1))]
    x=np.array(cross)
    idxs=np.where(x==1)[0]
    pairs=[(origin1[i],origin2[i]) for i in idxs]
    
    return sum(cross)/len(ma1),pairs
            
if __name__=='__main__':
    interval=10
    stock_path='Stk_1F_2016/SH000001.csv'
    save_filename=stock_path.split('/')[-1][:-4]
    save=True
    
    stock = readfile(stock_path)
    days,avgs=get_avgs(stock,interval,save,save_filename)
    
    stock_path='Stk_1F_2016/SH000002.csv'
    save_filename=stock_path.split('/')[-1][:-4]
    
    stock = readfile(stock_path)
    days,avgs=get_avgs(stock,interval,save,save_filename)
    
    date1,ma1=readMA('SH000001_ma.out')
    date2,ma2=readMA('SH000002_ma.out')
    
    ma11=getRise(ma1)
    ma22=getRise(ma2)
    
    JSim,pairs=getJSimilar(ma11,ma22,ma1,ma2)
    
    print(JSim)
    print(pairs)
    
    
    
    