# Project and system design report

## Functions

1. Utility tool for massive financial data set using MapReduce

   * Use mapreduce to get information with specific conditons in less time (e.g. get the days with closing price > opening price in parallel)

2. Algorithms repository for mining massive data sets

   * Make algorithm suitable for MapReduce

   * Calculate some attributes required for our strategy

3. Strategy repository with at least three trading strategies (planning)

   * FFSCORE Strategy
   * GRAHAM Strategy
   * PAIR TRADING Strategy

4. An ease of use UI for strategy presentation and interaction

   * Draw the pictures of data (e.g. moving average)
   * Interactive UI and interface to take in inputs