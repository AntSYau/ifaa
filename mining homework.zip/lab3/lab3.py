#lab3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import json

#read stocks with director array
def get_fileList(dirs):
    for d in dirs:
        fileList = []
        files = os.listdir(d)
        for f in files:  
            path=d+'/'+f
            if(os.path.isfile(path)):
                fileList.append(path)
    
    return fileList

#read stocks information in a file
def readfile(file):
    stock=[]
    with open(file) as f:
        lines=f.readlines()
        
    for line in lines:
        ls=line[:-1].split(',')
        stock.append(ls)
    
    return stock

def get_closing_prices(stock):
    days=[]
    closing_prices=[]
    for line in stock:
        if line[1]=='15:00':
            days.append(line[0])
            closing_prices.append(float(line[-3]))
    return days,closing_prices
    

def get_avgs(stock,interval,save):
    days,closing_prices=get_closing_prices(stock)

    length=len(closing_prices)
    if length<=interval:
        return [],[]
    
    avgs=[ sum(closing_prices[i-interval:i])/interval for i in range(interval,length)]
    days=days[interval:]
    
    if save:
        with open('bk.out','w') as f:
            f.write(json.dumps(days))
            f.write('\n')
            f.write(json.dumps(avgs))
    
    return days,avgs
        
def plot_avgs(days,avgs):
    tick_spacing=30
    fig, ax = plt.subplots(1,1)
    ax.tick_params(axis='x', rotation=45)
    ax.plot(days,avgs)
    ax.xaxis.set_major_locator(ticker.MultipleLocator(tick_spacing))
#     plt.savefig("avgs.png")
    plt.show()

if __name__=='__main__':

#     directorys=['Stk_1F_2016']
#     fileList=get_fileList(directorys)
#     fileList=['Stk_1F_2015/SH000001.csv','Stk_1F_2015/SH000002.csv']
    
    stock_path='Stk_1F_2016/SH000001.csv'
    interval=10
    save=True
    
    stock = readfile(stock_path)
    days,avgs=get_avgs(stock,interval,save)
    
    plot_avgs(days,avgs)