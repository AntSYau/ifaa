# LAB3

## How codes work

### Data Structure

* A date array
* A closing price array
* A moving average array

### Functions

* Set up the environment:  

  * filepath of stock
  * the interval of moving average
  * save the moving average data or not


![image-20190322133615388](/Users/do/Library/Application Support/typora-user-images/image-20190322133615388.png)

* get closing price of everyday ( the day sequence is in order)


![image-20190322133723426](/Users/do/Library/Application Support/typora-user-images/image-20190322133723426.png)

* get moving average data of everyday
  * the days without enough data is deleted

![image-20190322133904725](/Users/do/Library/Application Support/typora-user-images/image-20190322133904725.png)

* plot the data

  * the x tick spacing is 30 (about a month)

  ![image-20190322133951519](/Users/do/Library/Application Support/typora-user-images/image-20190322133951519.png)

  

  ## ![image-20190322134002351](/Users/do/Library/Application Support/typora-user-images/image-20190322134002351.png)
