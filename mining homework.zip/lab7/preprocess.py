import sys
import json

import nltk
import re
import string
from nltk.stem import PorterStemmer


# to preprocess issue content
class preprocess:
    def __init__(self):
        self.url_pattern = r'(?i)\b((?:[a-z][\w-]+:(?:/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:\'".,<>?«»“”‘’]))'
        self.translator = str.maketrans('', '', string.punctuation)
        self.wordEngStop = nltk.corpus.stopwords.words('english')
        self.code_pattern=re.compile('`{1,3}([\\s\\S]*?)`{1,3}[\\s]?')

    def rmvUrl(self, word):
        word = re.sub(self.url_pattern, "", word)
        return word

    def rmvSpace(self, word):
        word = word.replace('\r', ' ')
        word = word.replace('\n', ' ')
        word = word.lower()
        word = word.translate(self.translator)
        return word.split()

    def rmvStopwords(self, word):
        for i in range(len(word) - 1, -1, -1):
            if word[i] in self.wordEngStop:
                word.pop(i)

    def stemming(self, word):
        for i in range(len(word)):
            word[i] = PorterStemmer().stem(word[i])
        return word

    def getCode(self, word):
        code = self.code_pattern.findall(str(word))
        return code

    def rmvCode(self, word):
        word = re.sub(self.code_pattern, " ", word)
        return word

    def preprocess(self, title , word):
        title = self.rmvSpace(title)
        self.rmvStopwords(title)
        self.stemming(title)

        code = self.getCode(word)
        word = self.rmvCode(word)
        word = self.rmvUrl(word)
        word = self.rmvSpace(word)
        self.rmvStopwords(word)
        self.stemming(word)
        return title,word,code

