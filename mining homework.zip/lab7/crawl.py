import re
import requests

def getText(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'}
    response = requests.get(url, headers=headers).text
    rc = re.compile("\<.*?\>")
    r = rc.sub('', response)
    return r

def getBags(text):
    return text.split(' ');

def getJSimilarity(text1,text2):
    bags1,bags2=set(getBags(text1)),set(getBags(text2))
    count=0
    for word in bags1:
        if word in bags2:
            count+=1
    return count/(len(bags1)+len(bags2)-count)







