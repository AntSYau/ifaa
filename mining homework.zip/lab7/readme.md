# LAB7

1.从urls数组的url中爬取网站，利用正则表达式获取文本

![image-20190426181800199](/Users/do/Library/Application Support/typora-user-images/image-20190426181800199.png)

2.算similarity，得到两个文本的相似度信息

![image-20190426181744477](/Users/do/Library/Application Support/typora-user-images/image-20190426181744477.png)

3.超过threshold的被认为是指向的

![image-20190426181725684](/Users/do/Library/Application Support/typora-user-images/image-20190426181725684.png)

4.利用pagerank得到网站的值，排序

![image-20190426182519067](/Users/do/Library/Application Support/typora-user-images/image-20190426182519067.png)