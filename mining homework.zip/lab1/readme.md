# LAB1

## How codes work

### Data Structure

* All stocks are stored in a dictionary whose key is the stock id and the value is the stock information array.

* Each line of stock information are stored in an array.  

  ![image-20190308201319947](/Users/do/Library/Application Support/typora-user-images/image-20190308201319947.png)

### Functions

* Get stocks under director array or file list or a single file path

* Search a specific stock information with id, date and time

* Get stocks with days interval

  ![image-20190308215256102](/Users/do/Library/Application Support/typora-user-images/image-20190308215256102.png)

  

* Print a piece of stock information with this format:

  ![image-20190308214710289](/Users/do/Library/Application Support/typora-user-images/image-20190308214710289.png)

  

  

  ## Examples inside the code

  ![image-20190308215343677](/Users/do/Library/Application Support/typora-user-images/image-20190308215343677.png)

