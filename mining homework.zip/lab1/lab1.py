import time
import os

#print readable information
def readline(ls):
    stock={}
    stock['date'],stock['time'],stock['open_price'],stock['max_price'],stock['close_price'],stock['min_price'],stock['amount'],stock['volumn']=ls[0],ls[1],ls[2],ls[3],ls[4],ls[5],ls[6],ls[7]
    for k,v in stock.items():
        print('{}:{}'.format(k,v))
    return stock

#read stocks with director array
def readdirs(dirs):
    stocks=[]
    for d in dirs:
        fileList = []
        files = os.listdir(d)
        for f in files:  
            path=d+'/'+f
            if(os.path.isfile(path)):
                fileList.append(path)
    
    stocks=readfiles(fileList)
    return stocks

#read stocks with file path list 
def readfiles(fileList):
    stocks={}
    for path in fileList:  
        if(os.path.isfile(path)):
            id=path.split('/')[-1][:-4]
            stocks[id]=readfile(path)
    return stocks

#read stocks information in a file
def readfile(file):
    stock=[]
    with open(file) as f:
        lines=f.readlines()
        
    for line in lines:
        ls=line[:-1].split(',')
        stock.append(ls)
        
    
    return stock
   
#return stock information with stock id, date and time    
def search(stocks,stock_id,date,time):
    if stock_id not in stocks.keys():
        return None
    else:
        stock = stocks[stock_id]
        for s in stock:
            if s[0]==date and s[1]==time:
                return s
    return None
   
#used to return stocks in [yy,zz] days interval
def readfiles_input_days(fileList,yy,zz):
    stocks={}
    for path in fileList:  
        if(os.path.isfile(path)):
            id=path.split('/')[-1][:-4]
            stocks[id]=readfile_input_days(path,yy,zz)
    return stocks

#used to return stocks in [yy,zz] days interval
def readfile_input_days(file,yy,zz):
    stock=[]
    with open(file) as f:
        lines=f.readlines()
        
    for line in lines:
        ls=line[:-1].split(',')
        
        if compare_time(yy,ls[0],zz):
            stock.append(ls)
        
    return stock

# return True if time is in the [start,end] interval
def compare_time(start,tm,end):
    s=time.strptime(start,'%Y/%m/%d')
    e=time.strptime(end,'%Y/%m/%d')
    t=time.strptime(tm,'%Y/%m/%d')
    
    return t>=s and t<=e

# dirs=['Stk_1F_2015','Stk_1F_2016']
# stocks=readfile('Stk_1F_2015/SH000001.csv')
# stocks=readdirs(['Stk_1F_2015'])
#fileList=['Stk_1F_2015/SH000001.csv','Stk_1F_2015/SH000002.csv']
# stocks=readfiles(fileList)
# readline(search(stocks,'SH000002','2015/01/05','09:31'))
# stocks=readfiles_input_days(fileList,'2015/01/05','2015/01/05')
# compare_time('2015/01/05','2015/01/03','2015/02/05')

